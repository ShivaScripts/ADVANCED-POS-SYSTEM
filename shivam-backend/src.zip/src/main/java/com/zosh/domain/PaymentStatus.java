package com.zosh.domain;

public enum PaymentStatus {
    PENDING,SUCCESS,FAILED
}
