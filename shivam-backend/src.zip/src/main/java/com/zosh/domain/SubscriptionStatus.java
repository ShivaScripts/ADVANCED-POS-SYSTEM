package com.zosh.domain;

public enum SubscriptionStatus {

    TRIAL, ACTIVE, EXPIRED, CANCELLED
}
