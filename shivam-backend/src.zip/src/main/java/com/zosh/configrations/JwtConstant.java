package com.zosh.configrations;

public class JwtConstant {
 
	public static final String SECRET_KEY = "asdfghjklpoiuytrewqzxcvbnmlkjhglpouhggfdsawqwertyyuiioplmnbvcxzasdfgh";
	public static final String JWT_HEADER = "Authorization";
}
